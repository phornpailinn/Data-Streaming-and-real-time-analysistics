from confluent_kafka import Producer
import json
from faker import Faker
import random
from datetime import datetime
import time

# Kafka Configuration
KAFKA_TOPIC = "3_orders"
KAFKA_BROKERS = ["broker:29092"]

# Initialize Faker and Define Cosmetics-Related Constants
fake = Faker()
PRODUCT_NAMES = ["romand", "kiko", "4u2", "dinto", "etude"]
STATUSES = ["Shipped", "Pending", "Completed"]

# Create Producer
producer = Producer({'bootstrap.servers': ','.join(KAFKA_BROKERS)})

# Define the schema for the data
def get_order_schema():
    return {
        "type": "struct",
        "fields": [
            {"type": "string", "optional": False, "field": "order_id"},
            {"type": "string", "optional": False, "field": "users_id"},
            {"type": "string", "optional": False, "field": "order_date"},
            {"type": "float64", "optional": False, "field": "total_amount"},
            {"type": "string", "optional": False, "field": "status"},
            {"type": "string", "optional": False, "field": "product_name"}
        ],
        "optional": False,
        "name": "ksql.orders"
    }

# Generate order data with corresponding schema and payload
def generate_order_data():
    order_data = {
        "order_id": str(fake.uuid4()),
        "users_id": "User_" + str(random.randint(1, 9)),
        "order_date": datetime.now().isoformat(),
        "total_amount": round(random.uniform(10.0, 500.0), 2),
        "status": random.choice(STATUSES),
        "product_name": random.choice(PRODUCT_NAMES)
    }
    
    # Returning both schema and payload
    return {
        "schema": get_order_schema(),
        "payload": order_data
    }

# Function to produce orders to Kafka
def produce_orders():
    while True:
        order_message = generate_order_data()
        key = order_message["payload"]["users_id"]
        value = json.dumps(order_message)

        try:
            producer.produce(topic=KAFKA_TOPIC, key=key, value=value)
            print(f"Sent: {order_message}")
        except Exception as e:
            print(f"Error: {e}")
        time.sleep(1)

    producer.flush()

# Entry point
if __name__ == "__main__":
    try:
        produce_orders()
    except KeyboardInterrupt:
        print("Order data production stopped.")
    finally:
        producer.flush()
